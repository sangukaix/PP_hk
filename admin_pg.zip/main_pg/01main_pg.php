<?php
  // 세션 시작
  // 로그인 상태를 확인하려면 PHP 페이지 맨 위에서 session_start()를 실행해야 함
  session_start();
?>

<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hello Korean</title>

  <!-- 외부 CSS 연결 -->
  <link rel="stylesheet" href="./01main.css">
<link rel="stylesheet" href="../common/common.css">
</head>

<body>

<header>
  <div class="container">

    <a href="../main_pg/01main_pg.html">
      <img src="../main_pg/image/logo.png" alt="main_logo" class="logo">
    </a>

    <nav>
      <ul>
        <li><a href="../main_pg/01main_pg.html">Home</a></li>
        <li><a href="#">Course</a></li>
        <li><a href="#">Teacher</a></li>
        <li><a href="#">Price</a></li>
        <li><a href="../contact_pg/contact.html">Contact</a></li>
        <li><a href="../board_pg/board.html" class="board">Board</a></li>
<?php
  // 로그인한 상태인지 확인
  // login_ok.php에서 로그인 성공 시 $_SESSION['user_id']를 저장했음
  if(isset($_SESSION['user_id'])){
?>

    <!-- 로그인한 상태일 때: 로그인 버튼 대신 로그아웃 표시 -->
    <li>
      <a href="../member_pg/logout.php" class="login_btn">로그아웃</a>
    </li>

    <!-- 로그인한 상태일 때: 회원가입 버튼 대신 사용자 아이디 표시 -->
    <li>
      <a href="#" class="join_btn"><?php echo $_SESSION['user_id']; ?>님</a>
    </li>

<?php
  }else{
?>

    <!-- 로그인하지 않은 상태일 때: 로그인 / 회원가입 표시 -->
    <li>
      <a href="../member_pg/login.php" class="login_btn">로그인</a>
    </li>

    <li>
      <a href="../member_pg/join.php" class="join_btn">회원가입</a>
    </li>

<?php
  }
?>
      </ul>
    </nav>

  </div>
</header>

<main>

  <section id="main_visual">

    <div class="container">

      <h2>Learn Korean Online</h2>

      <p>
        외국인을 위한 온라인 한국어 회화 수업
      </p>

    </div>

  </section>

  <section id="intro">

    <div class="container">

      <article>
        <h3>1:1 Korean Class</h3>
        <p>전 세계 어디에서든 휴대폰만 있으면 온라인으로 수업을 들을 수 있습니다.</p>
      </article>

      <article>
        <h3>Professional Teacher</h3>
        <p>TOPIK 시험대비 과정으로 한국 국립대학교 유학 및 취업까지 연계.</p>
      </article>

      <article>
        <h3>Flexible Schedule</h3>
        <p>선생님과 수업 후 AI와 24시간 무한반복 연습.</p>
      </article>

    </div>

  </section>

</main>

<footer>

  <div class="container">

    <p>
      © Global Link Co., Ltd. All rights reserved.
    </p>

  </div>

</footer>

</body>
</html>