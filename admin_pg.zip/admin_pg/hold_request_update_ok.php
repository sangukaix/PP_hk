<?php
  // 관리자 로그인 체크
  include "./admin_check.php";

  // 한글 깨짐 방지
  header("Content-Type:text/html; charset=utf-8");

  // DB 연결
  include "../common/db.php";

  // GET 값 받기
  $request_no = $_GET['no'] ?? '';
  $action = $_GET['action'] ?? '';

  // 숫자 처리
  $request_no = (int)$request_no;

  // 잘못된 접근 체크
  if($request_no < 1){
    echo "
      <script>
        alert('잘못된 접근입니다.');
        location.href='./hold_request_list.php';
      </script>
    ";
    exit;
  }

  // 승인/반려 값 체크
  if($action != "approve" && $action != "reject"){
    echo "
      <script>
        alert('잘못된 처리값입니다.');
        location.href='./hold_request_list.php';
      </script>
    ";
    exit;
  }

  // 홀드 신청 정보 가져오기
  $sql = "
    SELECT *
    FROM hk_hold_requests
    WHERE no = '$request_no'
  ";

  $result = mysqli_query($db, $sql);

  if(!$result || mysqli_num_rows($result) < 1){
    echo "
      <script>
        alert('홀드 신청 정보를 찾을 수 없습니다.');
        location.href='./hold_request_list.php';
      </script>
    ";
    exit;
  }

  $request = mysqli_fetch_array($result, MYSQLI_ASSOC);

  // 이미 처리된 신청은 다시 처리하지 않음
  if($request['request_status'] != "대기"){
    echo "
      <script>
        alert('이미 처리된 요청입니다.');
        location.href='./hold_request_list.php';
      </script>
    ";
    exit;
  }

  $lesson_no = (int)$request['lesson_no'];
  $request_type = $request['request_type'];

  // ==============================
  // 승인 처리
  // ==============================
  if($action == "approve"){

    // 1. 요청 상태를 승인으로 변경
    $update_request_sql = "
      UPDATE hk_hold_requests
      SET
        request_status = '승인',
        processed_date = NOW()
      WHERE no = '$request_no'
    ";

    $request_result = mysqli_query($db, $update_request_sql);

    // 2. 요청 종류에 따라 실제 수업 상태 변경
    if($request_type == "홀드신청"){

      // 홀드신청 승인 → 수업 상태를 홀드로 변경
      $update_lesson_sql = "
        UPDATE hk_lesson_schedule
        SET attendance_status = '홀드'
        WHERE no = '$lesson_no'
      ";

    }else if($request_type == "홀드취소"){

      // 홀드취소 승인 → 수업 상태를 다시 예정으로 변경
      $update_lesson_sql = "
        UPDATE hk_lesson_schedule
        SET attendance_status = '예정'
        WHERE no = '$lesson_no'
      ";

    }else{

      echo "
        <script>
          alert('알 수 없는 요청 종류입니다.');
          location.href='./hold_request_list.php';
        </script>
      ";
      exit;
    }

    $lesson_result = mysqli_query($db, $update_lesson_sql);

    if($request_result && $lesson_result){

      if($request_type == "홀드신청"){
        $msg = "홀드 신청이 승인되었습니다.";
      }else{
        $msg = "홀드 취소 요청이 승인되었습니다.";
      }

      echo "
        <script>
          alert('$msg');
          location.href='./hold_request_list.php';
        </script>
      ";

    }else{
      echo "
        <script>
          alert('승인 처리 중 오류가 발생했습니다.');
          history.back();
        </script>
      ";
    }

  // ==============================
  // 반려 처리
  // ==============================
  }else if($action == "reject"){

    // 반려는 요청 상태만 반려로 변경
    // 홀드신청 반려 → 수업 상태는 예정 그대로
    // 홀드취소 반려 → 수업 상태는 홀드 그대로
    $reject_sql = "
      UPDATE hk_hold_requests
      SET
        request_status = '반려',
        processed_date = NOW()
      WHERE no = '$request_no'
    ";

    $reject_result = mysqli_query($db, $reject_sql);

    if($reject_result){

      if($request_type == "홀드신청"){
        $msg = "홀드 신청이 반려되었습니다.";
      }else{
        $msg = "홀드 취소 요청이 반려되었습니다.";
      }

      echo "
        <script>
          alert('$msg');
          location.href='./hold_request_list.php';
        </script>
      ";

    }else{
      echo "
        <script>
          alert('반려 처리 중 오류가 발생했습니다.');
          history.back();
        </script>
      ";
    }
  }

  mysqli_close($db);
?>